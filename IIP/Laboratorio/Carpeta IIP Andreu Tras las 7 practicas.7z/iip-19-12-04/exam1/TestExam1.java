package exam1;

import others.TimeInstant;
import java.util.Scanner;
/**
 * Classe TestExam1: classe programa que usa TimeInstant.
 *
 * @author IIP - Parcial 1
 * @version Curs 2019-20
 */
public class TestExam1 {
    /** No hi ha objectes d'aquesta classe. */ 
    private TestExam1() { }
    
    
    
    public static void main(String[] args) {
        // Lectura d'hores i minuts
        Scanner kbd = new Scanner(System.in);
        System.out.print("   -> Introdueix les hores (entre 0 i 23): ");
        int h = kbd.nextInt();
        System.out.print("   -> Introdueix els minuts (entre 0 i 59): ");
        int m = kbd.nextInt();
        // Una vegada llegides les dades d'hores i minuts des de teclat:
        // (a) Comprove si són correctes (0 <= h < 24 i 0 <= m < 60)
        // (b) Si ho són, ha de:
        //   - crear un TimeInstant a partir d'aquestes dades i 
        //     mostrar-lo per pantalla (en el format "hh:mm");
        //   - actualitzar les hores i els minuts del TimeInstant 
        //     reduint-los a la meitat i
        //   - mostrar-lo de nou per pantalla (en el mateix format).
        // (c) Si les dades no foren correctes, ha de mostrar per pantalla
        //     el missatge "Dades incorrectes!!"
        
        /* COMPLETAR */
        if (0 <= h && h < 24 && 0 <= m && m < 60) {
            TimeInstant t = new TimeInstant(h , m);                    
            System.out.println(t.toString());
            t.cutInHalf();
            
            System.out.println(t.toString());
        }
        
        else {
            System.out.println("Dades incorrectes!!");
        }        
        
        
    }    
}
