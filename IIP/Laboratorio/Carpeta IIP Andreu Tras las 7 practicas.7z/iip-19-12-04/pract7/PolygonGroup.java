package pract7;
import pract5.Point;
/**
 * Classe PolygonGroup. Grup de poligons en el pla.
 * Els poligons estan en ordre segons la sequencia en que s'afegeixen
 * al grup, de manera que es considera que cada poligon esta mes 
 * amunt en el grup que els poligons anteriors, o dit d'un altra 
 * manera, es superposa als anteriors. 
 * Se supose que l'ordre del grup dona la sequencia en que es dibuixen
 * els poligons, de manera que cadascun es dibuixa per damunt dels
 * anteriors, superposant-se a aquells amb els que solape.
 * 
 * A mes d'afegir poligons al grup, es pot seleccionar un poligon
 * per tal d'eliminar-lo, per traslladar les seues coordenades en el pla, 
 * o per canviar la seua posicio relativa en el grup: portar-lo al davant 
 * (damunt del tot), portar-lo al fons (baix del tot), ...
 * 
 * La manera de seleccionar el poligon a moure en el grup, es donant un
 * punt visible del poligon, es a dir, donant un punt que no pertanya
 * als poligons que apareixen superposats en el dibuix.
 *
 * @author IIP - Practica 7
 * @version Curs 2019/20
 */
public class PolygonGroup {    
    /* COMPLETAR la definicio de la constant, atribut de classe public */
    public static final int MAX = 10;
        
    /* COMPLETAR la definicio d'atributs d'instancia privats */
    private Polygon[] group;
    private int size;
    /**
     * Crea un grup de 0 poligons.
     */
    public PolygonGroup() {
        /* COMPLETAR */
        size = 0;
        group = new Polygon[MAX];
    }
    
    /** Afegeix al grup, damunt del tot, un poligon donat. 
     *  Si s'excedeix la capacitat del grup, el poligon 
     *  no s'afegeix.
     *  @param pol Polygon, el poligon.
     *  @return boolean, true si s'ha afegit o false en cas contrari.
     */
    public boolean add(Polygon pol) {
        /* COMPLETAR */
        boolean afegit = false;
        //Comprova el tamany, si fora mes gran que el MAX, no el afegix.
        if (size < MAX){
            group[size] = pol;
            size++;
            afegit = true;
        }
        
        return afegit;
    }
    
    /** Torna el numero de poligons del grup,  
     *  es a dir, la talla del grup.
     *  return int, la talla.
     */
    public int getSize() { 
        /* COMPLETAR */ 
        return size;
    }
    
    /** Elimina del grup el poligon seleccionat 
     *  pel punt p. El metode no fa res si no 
     *  hi ha cap poligon que continga a p.
     *  @param p Point, el punt.
     *  @return boolean, true si s'ha eliminat o false en cas contrari.     
     */
    public boolean remove(Point p) {
        /* COMPLETAR. Necesita metode SEARCH, que esta mes avall. */
        int posPol = search(p);  //Guarda posicio del poligon que conté al punt.
        boolean borrat = false;
        if (posPol != -1){
            //Revisa desde la pos del poligon al final i copia el següent a la pos actual.
            //Copia el 3 al 2, el 4 al 3, el 5 al 4... Lleva el hueco al borrar.
            for(int i = posPol; i < size -1; i++){
                group[i] = group[i+1];
            }
            //Reduix el tamany en 1. Aixi se podra afegir un altre si fora necessari.
            size--;
            //asigna la ultima posicio del array a null alliberant-la.
            group[size] = null;
            
            borrat = true;
        }
        return borrat;
    }
    
    /** Busca en el grup descendentment, de mes amunt
     *  a mes avall, el primer poligon que conte a un 
     *  punt donat, tornant la seua posicio en el grup.
     *  Si no existeix, torna -1.
     *  @param Point p, el punt.
     *  @return int, posicio en el grup del poligon que  
     *  conte al punt o -1 si no existeix.
     */
    private int search(Point p) {
        /* COMPLETAR */
        int posicio = -1;
        for (int i = size -1; i >= 0 && posicio == -1; i--) {
            /**
             * Manera 1: Curta de Gerard.
             * Es un condicional d'asignació. Posicio == condicio ? valorA:valorB
             * Si condicio = true -> valorA.
             * Si condicio = false -> ValorB.
             */ 
            // posicio = group[i].inside(p) ? i : posicio;
            
            //Manera 2: Manera 1 es equivalent a la següent:
            if (group[i].inside(p)){
                posicio = i;
            } else {
                posicio = posicio;
            }
        }
        return posicio;
    }
    
    /** Situa al davant del grup el poligon seleccionat 
     *  pel punt p. El metode no fa res si no 
     *  hi ha cap poligon que continga a p.
     *  @param p Point, el punt.
     */
    public void toFront(Point p) {
        /* COMPLETAR */
        int posPol = search(p); //Guarda en la variable la posicio del primer poligon 
                                  //que conte al punt
        if(posPol != -1) {
            //Guarde el polygon que conte al punt en un auxiliar mitjançant la posicio.
            Polygon auxPolygon = group[posPol];
            //Metode de dalt que borra el poligon que conté al punt p.
            // El metode remove d'abans s'assegura que no queda un hueco on estava el poligon.
            remove(p);
            //Metode de dalt que afegeix el poligon en la ultima posicio. Quedant al front.
            add(auxPolygon);
        }
    }
    
    /** Situa al fons del grup el poligon seleccionat 
     *  pel punt p. El metode no fa res si no 
     *  hi ha cap poligon que continga a p.
     *  @param p Point, el punt.
     */
    public void toBack(Point p) {
        /* COMPLETAR */
        int posPol = search(p); //Guarda en la variable la posicio del primer poligon 
                                  //que conte al punt
        if(posPol != -1){
            //Guarde el polygon que conte al punt en un auxiliar mitjançant la posicio.
            Polygon auxPolygon = group[posPol];
            
            //Mou els poligons en el grup de esquerra a dreta en el Array. Mou "el anterior"
            // en la posicio i actual.
            for (int i = posPol; i > 0; i--){
                group[i] = group[i - 1];
            }
            //Coloca en la posicio 0 del array el polygon que haviem guardat.
            group[0] = auxPolygon;
        }
    }
    
    /** Trasllada en el pla el poligon seleccionat 
     *  pel punt p. Les abscisses i les ordenades 
     *  dels seus vertexs s'incrementen o decrementen  
     *  en dos valors donats. El metode no fa res si no 
     *  hi ha cap poligon que continga a p.
     *  @param p Point, el punt.
     *  @param incX double, l'increment o decrement de les abscisses.
     *  @param incY double, l'increment o decrement de les ordenades.
     */
    public void translate(Point p, double incX, double incY) {
        /* COMPLETAR */
        int posPol = search(p); //Guarda en la variable la posicio del primer poligon 
                                  //que conte al punt
        if (posPol != -1){
            //Al poligon en questio dins del Array li pasa el metode de Polygon de 
            //translladar
            group[posPol].translate(incX, incY);
        }
    }
    
    /** Torna un array amb la sequencia de poligons del grup, 
     *  per ordre des del de mes avall al de mes amunt.
     *  @return Polygon[], l'array.
     */
    public Polygon[] toArray() {
        /* COMPLETAR */
        Polygon[] arrayPoli = new Polygon[size];
        for(int i = 0; i < size; i++){
            arrayPoli[i] = group[i];
        }
        return arrayPoli;
    } 
}
