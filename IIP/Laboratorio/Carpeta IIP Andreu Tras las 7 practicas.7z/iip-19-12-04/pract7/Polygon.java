package pract7;

import java.awt.Color;
import pract5.Point;
/**
 * Classe Polygon. Poligons solids (d'un determinat color) en el pla,
 * donats per la sequencia dels seus vertexs.
 * 
 * @author IIP - Practica 7
 * @version Curs 2019/20
 */
public class Polygon {    
    /* COMPLETAR la definicio d'atributs d'instancia privats */
    private Point[] v;
    private Color color;
    
    /**
     * Construeix un poligon a partir d'un array x amb les
     * abcsisses x0, x1, x2, ..., xn-1 dels seus vertexs, i un array y
     * amb les ordenades y0, y1, y2, ... yn-1 dels seus vertexs, n > 0.
     * Els vertexs defineixen un poligon els costats del qual s'extenen  
     * d'un vertex al seguent, i tancant-se en (x0,y0).
     * Per defecte, el poligon es de color blau (Color.BLUE).
     * @param x double[], les abscisses.
     * @param y double[], les ordenades.
     */
    public Polygon(double[] x, double[] y) {
        /* COMPLETAR */
        int numVertex = x.length;
        v = new Point[numVertex];
        color = Color.BLUE;
        for (int i = 0; i <= numVertex-1; i++) {
            v[i] = new Point (x[i], y[i]);
        }               
        
    }

    /** Torna les abscisses dels vertexs del poligon. 
     *  @return double[], les abscisses dels vertexs.
     */
    public double[] verticesX() {
        /* COMPLETAR */
        int numVertex = v.length;
        double[] vertX = new double[numVertex];
        for (int i = 0; i <= numVertex-1; i++) {
            vertX[i] = v[i].getX();
        }
        return vertX;
    }
    
    /** Torna les ordenades dels vertexs del poligon.
     *  @return double[], les ordenades dels vertexs. 
     */
    public double[] verticesY() {
        /* COMPLETAR */
        int numVertex = v.length;
        double[] vertY = new double[numVertex];
        for (int i = 0; i <= numVertex-1; i++) {
            vertY[i] = v[i].getY();
        }
        return vertY;
    }
    
    /** Torna el color del poligon.
     *  @return Color, el color. 
     */
    public Color getColor() {
        /* COMPLETAR */         
        return color;
    }
    
    /** Actualitza el color del poligon a un color donat.
     *  @param nC Color, el nou color.
     */
    public void setColor(Color nC) { 
        /* COMPLETAR */ 
        color = nC;
    }
        
     /** Torna el perimetre del poligon.
      *  @return double, el perimetre.
      */
     public double perimeter() {
         /* COMPLETAR */
         int numVertex = v.length;
         double sumaPerimetre = 0;
         // Major estricte per a que no tinga en conter l'ultim...
         for (int i = 0; i < numVertex - 1; i++) {
             sumaPerimetre = v[i].distance(v[i+1]) + sumaPerimetre;
         }
         //Si no te en conter l'ultim, podem sumar el antepenultim amb el
         //primer. Que es el que fa la següent linea.
            sumaPerimetre = v[numVertex-1].distance(v[0]) + sumaPerimetre;
         return sumaPerimetre;
     }   
    
    /** Trasllada els vertexs del poligon: 
     *  incX en l'eix X i incY en l'eix Y.
     *  @param incX double, l'increment o decrement en X.
     *  @param incY double, l'increment o decrement en Y.
     */
    public void translate(double incX, double incY) {
        /* COMPLETAR */
        int numVertex = v.length;
        // Metodo 1
        for (int i = 0; i <= numVertex-1; i++) {
            //Obtindre valor de X i I del punt que estem.
            double valorX = v[i].getX();
            double valorY = v[i].getY();
            //Guardar la coordenada + el increment.
            valorX = valorX + incX;
            valorY = valorY + incY;
            //Moure el punt a la nova coordenada (la inicial + increment).
            v[i].setX(valorX);
            v[i].setY(valorY);
        }

        //Metodo 2
        // double[] nuevoValorX = new double[numVertex];
        // double[] nuevoValorY = new double[numVertex];
        // for (int i = 0; i <= numVertex-1; i++) {
            // nuevoValorX = v[i].verticesX();
        // }
    }
          
    /** Comprova si el Point p es interior al poligon.
     *  PRECONDICIO: p no esta sobre els costats del poligon.
     *  Si el punt es interior al poligon, torna true; 
     *  en cas contrari, torna false.
     *  @param p Point, el punt.
     *  @return boolean, true si el punt es interior o false
     *  si es exterior.
     *  COMROVAR CROSS Y LOWCROSS i veure la suma. Si la suma es parella
     *  esta fora, si dona inparell dins. Sumar i++. Bucle.
     */
    public boolean inside(Point p) {
        /**
         * COMPLETAR. CARLOS. El meu esta baix per si aquest no anara. El
         * meu a priori deuria fucionar. Este el que te es que fa menys 
         * comprarancions que el meu ja que guarda en una variable un 
         * resultat. Son menys invocacions i a la llarga te major eficiencia
         * En lloc de fer 2 IFs, ho fa tot en 1 amb un ||.
         */
        int numVertex = v.length;
        //Si hace CROSS o LOWCROSS aumentara en 1 los cruces.
        int numCruces = 0;
        int aux;
        
        for (int i = 0; i < numVertex -1 ;i++) {
            //p.cross(v[i], v[i+1]   Lo que hace es mirar es si el punto p
            // cruza el segmento entre v[i] i v[i+1]
            aux = p.cross(v[i], v[i+1]);
            if (aux == Point.CROSS || aux == Point.LOW_CROSS){
                numCruces++;
            }

        }
            //Segment que tanca el penultim vertex amb l'inicial.
            aux = p.cross(v[numVertex-1] , v[0]);
            if (aux == Point.CROSS || aux == Point.LOW_CROSS) {numCruces++;}

        return numCruces % 2 == 1;
        
        // /* COMPLETAR. ANDREU. Deu funcionar. */
        // int numVertex = v.length;
        // //Si hace CROSS o LOWCROSS aumentara en 1 los cruces.
        // int numCruces = 0;
        // boolean posicionDentro = false;
        // for (int i = 0; i < numVertex;i++) {
            // //p.cross(v[i], v[i+1]   Lo que hace es mirar es si el punto p
            // // cruza el segmento entre v[i] i v[i+1]
            // if (p.cross(v[i], v[i+1])== p.CROSS){
                // numCruces++;
            // }
            // else if (p.cross(v[i], v[i+1])== p.LOW_CROSS) {
                // numCruces++;
            // }
        // }
            // //Segment que tanca el penultim vertex amb l'inicial.
            // if (p.cross(v[numVertex-1] , v[0]) == p.CROSS) {numCruces++;}
            // if (p.cross(v[numVertex-1] , v[0]) == p.LOW_CROSS) {numCruces++;}

            // if (numCruces % 2 == 1){posicionDentro = true;}

        // return posicionDentro;
        
        
        // // COMPLETAR. Gerard
        // int numVertex = v.length;
        // //Si hace CROSS o LOWCROSS aumentara en 1 los cruces.
        // int numCruces = 0;
        // int cross;
        // boolean posicionDentro = false;
        // for (int i = 0; i < numVertex -1;i++) {
            // cross = p.cross(v[i], v[i + 1]);
            // //p.cross(v[i], v[i+1]   Lo que hace es mirar es si el punto p
            // // cruza el segmento entre v[i] i v[i+1]
            // if (cross == Point.CROSS || cross == Point.LOW_CROSS){
                // numCruces++;
            // }
        // }
            // //Segment que tanca el penultim vertex amb l'inicial.
            // cross = p.cross(v[numVertex - 1], v[0]);
            // if(cross == Point.CROSS || cross == Point.LOW_CROSS){numCruces++;}
        
        // return numCruces % 2 == 1;
    } 
}
