package examExample;

import java.util.Scanner;
/**
 * Clase TestTimeInstant. 
 * 
 * @author IIP
 *  @version Curs 2019-20
 */
public class TestTimeInstant {
    
    public static void main(String[] args) {
        Scanner teclat = new Scanner(System.in);
        System.out.println("Lectura de teclat d'una hora.");
        System.out.print("   -> Introdueix les hores (entre 0 i 23): ");
        int h = teclat.nextInt();
        System.out.print("   -> Introdueix els minuts (entre 0 i 59): ");
        int m = teclat.nextInt();
        TimeInstant ti;
        /* COMPLETAR */
        if (0 <= h && h < 24 && 0 <= m && m < 60) {
           ti = new TimeInstant(h , m);
        }
        else {
            ti = new TimeInstant();
        }
        ti.decrement1Min();
        System.out.println("Despres: " + ti);
        //ti.decrement1Min();
        //System.out.println("Time instant menys 1 min " + ti.toString() );
    }
}