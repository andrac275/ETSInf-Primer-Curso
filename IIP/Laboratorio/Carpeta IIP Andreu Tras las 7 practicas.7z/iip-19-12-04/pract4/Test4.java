package pract4;

import java.util.Scanner;
import java.util.Locale;

/**
 * Clase Test 4.
 * Fa el mateix que la test 3 de la practica anterior pero aplicada a la classe
 * TimeInstant.
 *
 * @author Andreu
 * @version Pract4 16 Octubre
 */
public class Test4 {
    /**
     * Clase programa. Fa el mateix que la classe programa de la practica 
     * anterior pero cridant la clase TimeInstant.
     */
    public static void main(String[] args) {
        //Declaracio Scanner
        Scanner teclat = new Scanner(System.in).useLocale(Locale.US);
        //Mostra per pantalla que cal introduir hores y minuts.
        System.out.println("Lectura de teclat d'una hora + minuts.");
        System.out.print("Introduir hora: (entre 0 i 23)");
        int h = teclat.nextInt();
        System.out.print("Introduir minuts: (entre 0 i 59)");
        int m = teclat.nextInt();
        
        //Creacio objecte.
        TimeInstant t1 = new TimeInstant(h , m); 
        //Mostra per pantalla l'hora introduida.
        System.out.println("Hora introduida mitjançant parametres: " + t1);
        
        //Creacio objecte per defecte.
        System.out.println("La seguent hora es sense parametres");
        TimeInstant t2 = new TimeInstant();
        //Mostra per pantalla l'hora introduida.
        System.out.println("Hora UTC: " + t2);
        
        int diferencia = Math.abs(t1.compareTo(t2));
        System.out.println("La diferencia en minuts es: " 
            + diferencia + " (" + (diferencia / 60) + " horas y " 
            + (diferencia % 60) + " minuts.)");
            
        System.out.println("Escriu un valor en format hh:mm ");
        System.out.println("toString a veure si va..." + t1.toString());
        //TimeInstant t3 = new TimeInstant.valueOf(teclat.nextLine());
        //System.out.println("El objecte convertit es: " + t3);
        
                
    }
}
