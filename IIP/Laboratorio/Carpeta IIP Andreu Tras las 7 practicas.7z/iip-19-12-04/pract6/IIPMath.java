package pract6;

/**
 * Classe IIPMath: classe d'utilitats que implementa algunes operacions 
 * matematiques: IIPMath.sqrt(double) i IIPMath.log(double).
 *
 * @author IIP
 * @version Curs 2019-2020
 */
public class IIPMath {
    /** Valor aproximat de log(2). */
    /* COMPLETAR */
    public final static double LOG_2 = 0.6931471805599453;
    /** No es poden crear objectes d'aquesta classe. */
    private IIPMath() { }    
    
    /**
     * Torna l'arrel quadrada de x >= 0, amb error epsilon > 0. 
     * Declarar variables termCurr, error y termAnt.
     * Inicializar las variables error y termCurr.
     * La condicion del bucle es que la diferencia entre
     *      termAnt - termCurr sea >= epsilon.
     */
    public static double sqrt(double x, double epsilon) {
        /* COMPLETAR */        
        double termCurr = (1 + x) / 2;  //es Ti+1 en la formula
        double termAnt;  // es la Ti de la formula
                
        do{ 
            termAnt = termCurr;
            termCurr = (termAnt + (x / termAnt)) / 2;
            
        } while (termAnt - termCurr >= epsilon);
        return termCurr;
    }            

    /**
     * Torna l'arrel quadrada de x >= 0, amb error 1e-15. 
     * // COMPLETAR COMENTARIS
     * Metodo que llama al metodo sqrt anterior i pasa como parametros
     * un valor x introducido por el usuario y un error epsilon fijo.
     */
    public static double sqrt(double x) {    
        /* COMPLETAR */
        double error = 1e-15;
        return sqrt(x, error);
    }  
                    
    /**
     * Torna log(z), 1/2 <= z < 1, amb error epsilon > 0.
     * // COMPLETAR COMENTARIS
     */
    public static double logBase(double z, double epsilon) {
        /* COMPLETAR */
        double y = (1 - z) / (1 + z);
        int k = 1;        
        double termCurr = y;
        double sum = y;
        while (termCurr >= epsilon){
            termCurr = y * y * ((2.0 * k - 1) / (2 * k + 1)) * termCurr;
            sum += termCurr;
            k++;
        }
        
        return -2 * sum;
    }
            
    /**
     * Torna log(x), x > 0, amb error epsilon > 0.
     * // COMPLETAR COMENTARIS
     */
    public static double log(double x, double epsilon) {      
        /* COMPLETAR */
        double k = 0;
        double z = x;
        double resultado;
        
        if (z == 1) {
            resultado = 0;
        } else if (z >= 0.5 && z < 1) { 
            resultado = logBase (z, epsilon);
        } else {
            while (z >= 1){
                z = z / 2;
                k++;
            }
            
            while (z < 0.5){
                z = z * 2;
                k--;
            }
            
        }
        resultado = k * LOG_2 + logBase(z , epsilon);
        return resultado;
    }

    /**
     * Torna log(x), x > 0, amb error 1e-15.
     * // COMPLETAR COMENTARIS
     */
    public static double log(double x) {    
        /* COMPLETAR */
        double error = 1e-15;
        return log(x,error);
    }
                     
}
