package pract3;

import java.util.Scanner;

/**
 *  Classe Test3.
 *  Una primera classe amb lectura de dades des de teclat, 
 *  i us d'operacions amb int, long, Math i String.
 *  Conte tres errors de compilacio.
 *  @author IIP 
 *  @version Curs 2019-20
 */
 
public class Test3 {

    public static void main(String[] args) {
        Scanner kbd = new Scanner(System.in);
        System.out.println("Lectura de teclat d'una hora.");
        System.out.print(" -> Introduiu les hores (entre 0 i 23): ");
        int h = kbd.nextInt();
        System.out.print(" -> Introduiu els minuts (entre 0 i 59): ");
        int m = kbd.nextInt();
        //System.out.println("Hora introduida: " + h + " i " + m);  
        
        //ACTIVITAT 4
        //convertir string amb un 0 davant
        String hh, mm;
        hh = "0" + h;
        mm = "0" + m;
        //lleva caracters de mes. Deixa nomes els 2 ultims.
        hh = hh.substring(hh.length() - 2);
        mm = mm.substring(mm.length() - 2);
        
        //Torna l'hora per pantalla
        System.out.println("Hora introduida: " + hh + ":" + mm); 
        
        //ACTIVITAT 5
        //minuts des del inici del univers Temps UCT
        long tMinTotal = System.currentTimeMillis() / (60 * 1000);
        //minuts de hui
        int tMinCurrent = (int) (tMinTotal % (24 * 60));
        
        int hC, mC;
        //hores d'avui
        hC = tMinCurrent / 60;
        //minuts d'avui
        mC = tMinCurrent % 60;
        //convertir string amb un 0 davant
        String hhC, mmC;
        hhC = "0" + hC;
        mmC = "0" + hC;
        //lleva caracters de mes. Deixa nomes els 2 ultims.
        hhC = hhC.substring(hhC.length() - 2);
        mmC = mmC.substring(mmC.length() - 2);
        
        //Hora UCT per pantalla
        System.out.println("Hora: " + hhC + ":" + mmC + " en temps UTC"); 
        
        //ACTIVITAT 5. Diferencia hora actual amb hora univers UTC.
        //Minuts d'avui menys minuts introduits menys hores introduides pasades a minuts
        int dif = Math.abs(tMinCurrent - m - h * 60);
        System.out.println("La diferencia entre l'hora introduida i la UTC es: "
            + dif + " minuts que son, " + (dif / 60) + " hores i " + (dif % 60) + " minuts.");
        
    }    
 
}
