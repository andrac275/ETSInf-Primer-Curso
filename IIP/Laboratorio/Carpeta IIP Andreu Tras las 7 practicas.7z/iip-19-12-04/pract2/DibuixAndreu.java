package pract2;


/**
 * Primer Dibuix Andreu
 *
 * Andreu Mut
 * 25/9/2019
 */
public class DibuixAndreu {
    /** No hi ha objectes d'aquesta classe */
    private DibuixAndreu() { }

    public static void main(String[] args) {         
        // Crear la pissarra on vaig a fer el dibuix. Amb nom i dimensions.
        Blackboard meuaPissarra = new Blackboard("Dibuix Andreu", 500, 500);
        
        //Base de la casa
        Rectangle base = new Rectangle(200, 200, "yellow", 250, 400);
        meuaPissarra.add(base);
        
        //Sostre de la casa
        TrIsosceles sostre = new TrIsosceles(200, 100, "red", 250, 270);
        meuaPissarra.add(sostre);
        
        //Porta de la casa
        Rectangle porta = new Rectangle(50, 80, "blue", 250, 430);
        meuaPissarra.add(porta);
        
        //Finestra sostre
        Circle finsos = new Circle(20, "cyan", 250, 270);
        meuaPissarra.add(finsos);
                
        //Finestra dreta
        Rectangle findret = new Rectangle(40, 40, "cyan", 310, 420);
        meuaPissarra.add(findret);
        
        //Finestra esquerra
        Rectangle finesq = new Rectangle(40, 40, "cyan", 190, 420);
        meuaPissarra.add(finesq);
        
        //Tronc arbre
        Rectangle tronc = new Rectangle(20, 200, "brown" , 400, 400);
        meuaPissarra.add(tronc);
        
        //Copa arbre
        TrIsosceles copa = new TrIsosceles(50, 100, "green", 400, 300);
        meuaPissarra.add(copa);
        
    }
    
}
